package com.example.ticketapp.activities;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.ticketapp.R;
import com.example.ticketapp.database.DatabaseHelper;
import com.example.ticketapp.models.User;
import com.google.android.material.textfield.TextInputEditText;

public class RegisterActivity extends AppCompatActivity {

    private TextInputEditText etName, etEmail, etPassword, etConfirm;
    private DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        db = new DatabaseHelper(this);

        etName    = findViewById(R.id.etName);
        etEmail   = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        etConfirm  = findViewById(R.id.etConfirmPassword);
        Button btnRegister = findViewById(R.id.btnRegister);
        TextView tvLogin   = findViewById(R.id.tvLogin);

        btnRegister.setOnClickListener(v -> register());
        tvLogin.setOnClickListener(v -> finish());
    }

    private void register() {
        String name    = str(etName);
        String email   = str(etEmail);
        String pass    = str(etPassword);
        String confirm = str(etConfirm);

        if (TextUtils.isEmpty(name))   { etName.setError("Informe o nome"); return; }
        if (TextUtils.isEmpty(email) || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            etEmail.setError("E-mail inválido"); return;
        }
        if (pass.length() < 6) { etPassword.setError("Mínimo 6 caracteres"); return; }
        if (!pass.equals(confirm)) { etConfirm.setError("Senhas não conferem"); return; }
        if (db.emailExists(email)) { etEmail.setError("E-mail já cadastrado"); return; }

        if (db.registerUser(new User(name, email, pass))) {
            Toast.makeText(this, "Cadastro realizado! Faça login 🎉", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Erro ao cadastrar. Tente novamente.", Toast.LENGTH_SHORT).show();
        }
    }

    private String str(TextInputEditText et) {
        return et.getText() != null ? et.getText().toString().trim() : "";
    }
}
