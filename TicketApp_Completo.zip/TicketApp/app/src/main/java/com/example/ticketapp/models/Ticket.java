package com.example.ticketapp.models;

public class Ticket {
    private int id;
    private String eventName, location, eventDate, category;
    private double price;
    private int quantity;

    public Ticket() {}

    public Ticket(String eventName, String location, String eventDate,
                  String category, double price, int quantity) {
        this.eventName = eventName; this.location = location;
        this.eventDate = eventDate; this.category = category;
        this.price = price; this.quantity = quantity;
    }

    public Ticket(int id, String eventName, String location, String eventDate,
                  String category, double price, int quantity) {
        this.id = id; this.eventName = eventName; this.location = location;
        this.eventDate = eventDate; this.category = category;
        this.price = price; this.quantity = quantity;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getEventName() { return eventName; }
    public void setEventName(String eventName) { this.eventName = eventName; }
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
    public String getEventDate() { return eventDate; }
    public void setEventDate(String eventDate) { this.eventDate = eventDate; }
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }
    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
}
