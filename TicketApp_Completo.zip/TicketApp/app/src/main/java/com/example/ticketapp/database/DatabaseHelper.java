package com.example.ticketapp.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.ticketapp.models.Ticket;
import com.example.ticketapp.models.User;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "TicketApp.db";
    private static final int DB_VERSION = 1;

    // Users
    private static final String T_USERS   = "users";
    private static final String U_ID      = "id";
    private static final String U_NAME    = "name";
    private static final String U_EMAIL   = "email";
    private static final String U_PASS    = "password";

    // Tickets
    private static final String T_TICKETS = "tickets";
    private static final String TK_ID     = "id";
    private static final String TK_EVENT  = "event_name";
    private static final String TK_LOC    = "location";
    private static final String TK_DATE   = "event_date";
    private static final String TK_CAT    = "category";
    private static final String TK_PRICE  = "price";
    private static final String TK_QTY    = "quantity";

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + T_USERS + " (" +
                U_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                U_NAME + " TEXT NOT NULL, " +
                U_EMAIL + " TEXT UNIQUE NOT NULL, " +
                U_PASS + " TEXT NOT NULL)");

        db.execSQL("CREATE TABLE " + T_TICKETS + " (" +
                TK_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                TK_EVENT + " TEXT NOT NULL, " +
                TK_LOC + " TEXT, " +
                TK_DATE + " TEXT, " +
                TK_CAT + " TEXT, " +
                TK_PRICE + " REAL NOT NULL, " +
                TK_QTY + " INTEGER NOT NULL)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int o, int n) {
        db.execSQL("DROP TABLE IF EXISTS " + T_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + T_TICKETS);
        onCreate(db);
    }

    // ─── USERS ───────────────────────────────────────────────────────────────

    public boolean registerUser(User user) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(U_NAME, user.getName());
        cv.put(U_EMAIL, user.getEmail());
        cv.put(U_PASS, user.getPassword());
        long r = db.insert(T_USERS, null, cv);
        db.close();
        return r != -1;
    }

    public User loginUser(String email, String password) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(T_USERS, null,
                U_EMAIL + "=? AND " + U_PASS + "=?",
                new String[]{email, password}, null, null, null);
        User user = null;
        if (c != null && c.moveToFirst()) {
            user = new User(
                    c.getInt(c.getColumnIndexOrThrow(U_ID)),
                    c.getString(c.getColumnIndexOrThrow(U_NAME)),
                    c.getString(c.getColumnIndexOrThrow(U_EMAIL)),
                    c.getString(c.getColumnIndexOrThrow(U_PASS)));
            c.close();
        }
        db.close();
        return user;
    }

    public boolean emailExists(String email) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(T_USERS, null, U_EMAIL + "=?",
                new String[]{email}, null, null, null);
        boolean exists = c != null && c.getCount() > 0;
        if (c != null) c.close();
        db.close();
        return exists;
    }

    // ─── TICKETS ─────────────────────────────────────────────────────────────

    public boolean addTicket(Ticket t) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = buildCV(t);
        long r = db.insert(T_TICKETS, null, cv);
        db.close();
        return r != -1;
    }

    public List<Ticket> getAllTickets() {
        return query("SELECT * FROM " + T_TICKETS + " ORDER BY " + TK_EVENT, null);
    }

    public Ticket getTicketById(int id) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(T_TICKETS, null, TK_ID + "=?",
                new String[]{String.valueOf(id)}, null, null, null);
        Ticket t = null;
        if (c != null && c.moveToFirst()) { t = fromCursor(c); c.close(); }
        db.close();
        return t;
    }

    public boolean updateTicket(Ticket t) {
        SQLiteDatabase db = getWritableDatabase();
        int rows = db.update(T_TICKETS, buildCV(t),
                TK_ID + "=?", new String[]{String.valueOf(t.getId())});
        db.close();
        return rows > 0;
    }

    public boolean deleteTicket(int id) {
        SQLiteDatabase db = getWritableDatabase();
        int rows = db.delete(T_TICKETS, TK_ID + "=?", new String[]{String.valueOf(id)});
        db.close();
        return rows > 0;
    }

    public List<Ticket> searchTickets(String q) {
        String like = "%" + q + "%";
        return query("SELECT * FROM " + T_TICKETS +
                " WHERE " + TK_EVENT + " LIKE ? OR " + TK_LOC + " LIKE ?" +
                " ORDER BY " + TK_EVENT, new String[]{like, like});
    }

    // ─── helpers ─────────────────────────────────────────────────────────────

    private ContentValues buildCV(Ticket t) {
        ContentValues cv = new ContentValues();
        cv.put(TK_EVENT, t.getEventName());
        cv.put(TK_LOC,   t.getLocation());
        cv.put(TK_DATE,  t.getEventDate());
        cv.put(TK_CAT,   t.getCategory());
        cv.put(TK_PRICE, t.getPrice());
        cv.put(TK_QTY,   t.getQuantity());
        return cv;
    }

    private Ticket fromCursor(Cursor c) {
        return new Ticket(
                c.getInt(c.getColumnIndexOrThrow(TK_ID)),
                c.getString(c.getColumnIndexOrThrow(TK_EVENT)),
                c.getString(c.getColumnIndexOrThrow(TK_LOC)),
                c.getString(c.getColumnIndexOrThrow(TK_DATE)),
                c.getString(c.getColumnIndexOrThrow(TK_CAT)),
                c.getDouble(c.getColumnIndexOrThrow(TK_PRICE)),
                c.getInt(c.getColumnIndexOrThrow(TK_QTY)));
    }

    private List<Ticket> query(String sql, String[] args) {
        List<Ticket> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery(sql, args);
        if (c.moveToFirst()) { do { list.add(fromCursor(c)); } while (c.moveToNext()); }
        c.close(); db.close();
        return list;
    }
}
