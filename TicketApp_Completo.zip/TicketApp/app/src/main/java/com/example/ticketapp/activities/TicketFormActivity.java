package com.example.ticketapp.activities;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.example.ticketapp.R;
import com.example.ticketapp.database.DatabaseHelper;
import com.example.ticketapp.models.Ticket;
import com.google.android.material.textfield.TextInputEditText;

public class TicketFormActivity extends AppCompatActivity {

    private TextInputEditText etEvent, etLocation, etDate, etPrice, etQuantity;
    private AutoCompleteTextView etCategory;
    private DatabaseHelper db;
    private int ticketId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ticket_form);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationOnClickListener(v -> finish());

        db = new DatabaseHelper(this);

        etEvent    = findViewById(R.id.etEvent);
        etLocation = findViewById(R.id.etLocation);
        etDate     = findViewById(R.id.etDate);
        etCategory = findViewById(R.id.etCategory);
        etPrice    = findViewById(R.id.etPrice);
        etQuantity = findViewById(R.id.etQuantity);
        Button btnSave   = findViewById(R.id.btnSave);
        Button btnCancel = findViewById(R.id.btnCancel);

        // Categorias dropdown
        String[] cats = {"Show", "Festival", "Teatro", "Cinema", "Esporte", "Stand-up", "Outro"};
        etCategory.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_dropdown_item_1line, cats));

        ticketId = getIntent().getIntExtra("ticketId", -1);
        if (ticketId != -1) {
            if (getSupportActionBar() != null) getSupportActionBar().setTitle("Editar Ingresso");
            loadTicket();
        } else {
            if (getSupportActionBar() != null) getSupportActionBar().setTitle("Novo Ingresso");
        }

        btnSave.setOnClickListener(v -> save());
        btnCancel.setOnClickListener(v -> finish());
    }

    private void loadTicket() {
        Ticket t = db.getTicketById(ticketId);
        if (t != null) {
            etEvent.setText(t.getEventName());
            etLocation.setText(t.getLocation());
            etDate.setText(t.getEventDate());
            etCategory.setText(t.getCategory(), false);
            etPrice.setText(String.valueOf(t.getPrice()));
            etQuantity.setText(String.valueOf(t.getQuantity()));
        }
    }

    private void save() {
        String event    = str(etEvent);
        String location = str(etLocation);
        String date     = str(etDate);
        String category = etCategory.getText().toString().trim();
        String priceStr = str(etPrice);
        String qtyStr   = str(etQuantity);

        if (TextUtils.isEmpty(event))    { etEvent.setError("Informe o nome do evento"); return; }
        if (TextUtils.isEmpty(priceStr)) { etPrice.setError("Informe o preço"); return; }
        if (TextUtils.isEmpty(qtyStr))   { etQuantity.setError("Informe a quantidade"); return; }

        double price; int qty;
        try {
            price = Double.parseDouble(priceStr);
            qty   = Integer.parseInt(qtyStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Valores numéricos inválidos", Toast.LENGTH_SHORT).show();
            return;
        }
        if (price < 0 || qty < 0) {
            Toast.makeText(this, "Preço e quantidade não podem ser negativos", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean ok;
        if (ticketId != -1) {
            ok = db.updateTicket(new Ticket(ticketId, event, location, date, category, price, qty));
            Toast.makeText(this, ok ? "Ingresso atualizado! ✅" : "Erro ao atualizar.", Toast.LENGTH_SHORT).show();
        } else {
            ok = db.addTicket(new Ticket(event, location, date, category, price, qty));
            Toast.makeText(this, ok ? "Ingresso cadastrado! 🎟️" : "Erro ao salvar.", Toast.LENGTH_SHORT).show();
        }
        if (ok) finish();
    }

    private String str(TextInputEditText et) {
        return et.getText() != null ? et.getText().toString().trim() : "";
    }
}
