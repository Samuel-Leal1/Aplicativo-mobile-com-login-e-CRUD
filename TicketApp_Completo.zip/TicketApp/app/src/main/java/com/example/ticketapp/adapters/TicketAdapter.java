package com.example.ticketapp.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ticketapp.R;
import com.example.ticketapp.models.Ticket;

import java.util.List;
import java.util.Locale;

public class TicketAdapter extends RecyclerView.Adapter<TicketAdapter.VH> {

    private final List<Ticket> list;
    private final OnTicketClickListener listener;

    public interface OnTicketClickListener {
        void onEditClick(Ticket ticket);
        void onDeleteClick(Ticket ticket);
    }

    public TicketAdapter(List<Ticket> list, OnTicketClickListener listener) {
        this.list = list;
        this.listener = listener;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_ticket, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int pos) {
        Ticket t = list.get(pos);
        Context ctx = h.itemView.getContext();

        h.tvEvent.setText(t.getEventName());

        h.tvLocation.setText((t.getLocation() != null && !t.getLocation().isEmpty())
                ? "📍 " + t.getLocation() : "📍 Local não informado");

        h.tvDate.setText((t.getEventDate() != null && !t.getEventDate().isEmpty())
                ? "🗓️ " + t.getEventDate() : "🗓️ Data não informada");

        h.tvCategory.setText((t.getCategory() != null && !t.getCategory().isEmpty())
                ? t.getCategory() : "Geral");

        h.tvPrice.setText(String.format(Locale.getDefault(), "R$ %.2f", t.getPrice()));

        int qty = t.getQuantity();
        if (qty == 0) {
            h.tvStatus.setText("Esgotado");
            h.tvStatus.setBackgroundResource(R.drawable.bg_badge_red);
            h.tvStatus.setTextColor(ContextCompat.getColor(ctx, R.color.status_sold_out));
        } else if (qty <= 10) {
            h.tvStatus.setText("Poucos: " + qty);
            h.tvStatus.setBackgroundResource(R.drawable.bg_badge_orange);
            h.tvStatus.setTextColor(ContextCompat.getColor(ctx, R.color.status_few));
        } else {
            h.tvStatus.setText("Disponível: " + qty);
            h.tvStatus.setBackgroundResource(R.drawable.bg_badge_green);
            h.tvStatus.setTextColor(ContextCompat.getColor(ctx, R.color.status_available));
        }

        h.btnEdit.setOnClickListener(v -> listener.onEditClick(t));
        h.btnDelete.setOnClickListener(v -> listener.onDeleteClick(t));
    }

    @Override
    public int getItemCount() { return list.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView tvEvent, tvLocation, tvDate, tvCategory, tvPrice, tvStatus;
        ImageButton btnEdit, btnDelete;

        VH(@NonNull View v) {
            super(v);
            tvEvent    = v.findViewById(R.id.tvEvent);
            tvLocation = v.findViewById(R.id.tvLocation);
            tvDate     = v.findViewById(R.id.tvDate);
            tvCategory = v.findViewById(R.id.tvCategory);
            tvPrice    = v.findViewById(R.id.tvPrice);
            tvStatus   = v.findViewById(R.id.tvStatus);
            btnEdit    = v.findViewById(R.id.btnEdit);
            btnDelete  = v.findViewById(R.id.btnDelete);
        }
    }
}
