package com.example.ticketapp.activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.ticketapp.R;
import com.example.ticketapp.adapters.TicketAdapter;
import com.example.ticketapp.database.DatabaseHelper;
import com.example.ticketapp.models.Ticket;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.List;

public class MainActivity extends AppCompatActivity implements TicketAdapter.OnTicketClickListener {

    private RecyclerView recyclerView;
    private TicketAdapter adapter;
    private DatabaseHelper db;
    private TextView tvEmpty, tvWelcome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        db = new DatabaseHelper(this);
        tvWelcome   = findViewById(R.id.tvWelcome);
        tvEmpty     = findViewById(R.id.tvEmpty);
        recyclerView = findViewById(R.id.recyclerView);
        FloatingActionButton fab = findViewById(R.id.fabAdd);

        SharedPreferences prefs = getSharedPreferences("session", MODE_PRIVATE);
        tvWelcome.setText("Olá, " + prefs.getString("userName", "") + " 👋");

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        fab.setOnClickListener(v -> startActivity(new Intent(this, TicketFormActivity.class)));

        loadTickets();
    }

    @Override
    protected void onResume() { super.onResume(); loadTickets(); }

    private void loadTickets() { showList(db.getAllTickets()); }

    private void showList(List<Ticket> list) {
        if (list.isEmpty()) {
            tvEmpty.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.GONE);
        } else {
            tvEmpty.setVisibility(View.GONE);
            recyclerView.setVisibility(View.VISIBLE);
            adapter = new TicketAdapter(list, this);
            recyclerView.setAdapter(adapter);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        MenuItem searchItem = menu.findItem(R.id.action_search);
        SearchView sv = (SearchView) searchItem.getActionView();
        sv.setQueryHint("Buscar evento ou local...");
        sv.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override public boolean onQueryTextSubmit(String q) { return false; }
            @Override public boolean onQueryTextChange(String t) {
                showList(t.isEmpty() ? db.getAllTickets() : db.searchTickets(t));
                return true;
            }
        });
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_logout) {
            new AlertDialog.Builder(this)
                    .setTitle("Sair")
                    .setMessage("Deseja realmente sair?")
                    .setPositiveButton("Sair", (d, w) -> logout())
                    .setNegativeButton("Cancelar", null)
                    .show();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void logout() {
        getSharedPreferences("session", MODE_PRIVATE).edit().clear().apply();
        startActivity(new Intent(this, LoginActivity.class));
        finish();
    }

    @Override
    public void onEditClick(Ticket ticket) {
        Intent i = new Intent(this, TicketFormActivity.class);
        i.putExtra("ticketId", ticket.getId());
        startActivity(i);
    }

    @Override
    public void onDeleteClick(Ticket ticket) {
        new AlertDialog.Builder(this)
                .setTitle("Excluir Ingresso")
                .setMessage("Excluir \"" + ticket.getEventName() + "\"?")
                .setPositiveButton("Excluir", (d, w) -> {
                    if (db.deleteTicket(ticket.getId())) {
                        Toast.makeText(this, "Ingresso excluído!", Toast.LENGTH_SHORT).show();
                        loadTickets();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }
}
