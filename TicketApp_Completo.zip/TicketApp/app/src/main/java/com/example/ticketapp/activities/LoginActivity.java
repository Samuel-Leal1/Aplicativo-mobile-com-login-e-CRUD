package com.example.ticketapp.activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.ticketapp.R;
import com.example.ticketapp.database.DatabaseHelper;
import com.example.ticketapp.models.User;
import com.google.android.material.textfield.TextInputEditText;

public class LoginActivity extends AppCompatActivity {

    private TextInputEditText etEmail, etPassword;
    private DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SharedPreferences prefs = getSharedPreferences("session", MODE_PRIVATE);
        if (prefs.getBoolean("loggedIn", false)) {
            go(MainActivity.class);
            return;
        }

        setContentView(R.layout.activity_login);
        db = new DatabaseHelper(this);

        etEmail    = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        Button btnLogin    = findViewById(R.id.btnLogin);
        TextView tvRegister = findViewById(R.id.tvRegister);

        btnLogin.setOnClickListener(v -> login());
        tvRegister.setOnClickListener(v -> go(RegisterActivity.class));
    }

    private void login() {
        String email = str(etEmail), pass = str(etPassword);
        if (TextUtils.isEmpty(email)) { etEmail.setError("Informe o e-mail"); return; }
        if (TextUtils.isEmpty(pass))  { etPassword.setError("Informe a senha"); return; }

        User user = db.loginUser(email, pass);
        if (user != null) {
            getSharedPreferences("session", MODE_PRIVATE).edit()
                    .putBoolean("loggedIn", true)
                    .putString("userName", user.getName())
                    .putString("userEmail", user.getEmail())
                    .apply();
            Toast.makeText(this, "Bem-vindo, " + user.getName() + "! 🎟️", Toast.LENGTH_SHORT).show();
            go(MainActivity.class);
        } else {
            Toast.makeText(this, "E-mail ou senha inválidos", Toast.LENGTH_SHORT).show();
        }
    }

    private String str(TextInputEditText et) {
        return et.getText() != null ? et.getText().toString().trim() : "";
    }

    private void go(Class<?> cls) {
        startActivity(new Intent(this, cls));
        finish();
    }
}
