package com.example.crudapp.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.crudapp.models.Product;
import com.example.crudapp.models.User;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "CrudApp.db";
    private static final int DATABASE_VERSION = 1;

    // Tabela de usuários
    public static final String TABLE_USERS = "users";
    public static final String COL_USER_ID = "id";
    public static final String COL_USER_NAME = "name";
    public static final String COL_USER_EMAIL = "email";
    public static final String COL_USER_PASSWORD = "password";

    // Tabela de produtos
    public static final String TABLE_PRODUCTS = "products";
    public static final String COL_PRODUCT_ID = "id";
    public static final String COL_PRODUCT_NAME = "name";
    public static final String COL_PRODUCT_DESCRIPTION = "description";
    public static final String COL_PRODUCT_PRICE = "price";
    public static final String COL_PRODUCT_QUANTITY = "quantity";

    private static final String CREATE_TABLE_USERS =
            "CREATE TABLE " + TABLE_USERS + " (" +
            COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            COL_USER_NAME + " TEXT NOT NULL, " +
            COL_USER_EMAIL + " TEXT UNIQUE NOT NULL, " +
            COL_USER_PASSWORD + " TEXT NOT NULL" +
            ")";

    private static final String CREATE_TABLE_PRODUCTS =
            "CREATE TABLE " + TABLE_PRODUCTS + " (" +
            COL_PRODUCT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            COL_PRODUCT_NAME + " TEXT NOT NULL, " +
            COL_PRODUCT_DESCRIPTION + " TEXT, " +
            COL_PRODUCT_PRICE + " REAL NOT NULL, " +
            COL_PRODUCT_QUANTITY + " INTEGER NOT NULL" +
            ")";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_USERS);
        db.execSQL(CREATE_TABLE_PRODUCTS);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PRODUCTS);
        onCreate(db);
    }

    // ===================== USUÁRIOS =====================

    public boolean registerUser(User user) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_USER_NAME, user.getName());
        values.put(COL_USER_EMAIL, user.getEmail());
        values.put(COL_USER_PASSWORD, user.getPassword());
        long result = db.insert(TABLE_USERS, null, values);
        db.close();
        return result != -1;
    }

    public User loginUser(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS, null,
                COL_USER_EMAIL + "=? AND " + COL_USER_PASSWORD + "=?",
                new String[]{email, password}, null, null, null);
        User user = null;
        if (cursor != null && cursor.moveToFirst()) {
            user = new User(
                    cursor.getInt(cursor.getColumnIndexOrThrow(COL_USER_ID)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COL_USER_NAME)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COL_USER_EMAIL)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COL_USER_PASSWORD))
            );
            cursor.close();
        }
        db.close();
        return user;
    }

    public boolean emailExists(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS, null,
                COL_USER_EMAIL + "=?", new String[]{email},
                null, null, null);
        boolean exists = cursor != null && cursor.getCount() > 0;
        if (cursor != null) cursor.close();
        db.close();
        return exists;
    }

    // ===================== PRODUTOS =====================

    public boolean addProduct(Product product) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_PRODUCT_NAME, product.getName());
        values.put(COL_PRODUCT_DESCRIPTION, product.getDescription());
        values.put(COL_PRODUCT_PRICE, product.getPrice());
        values.put(COL_PRODUCT_QUANTITY, product.getQuantity());
        long result = db.insert(TABLE_PRODUCTS, null, values);
        db.close();
        return result != -1;
    }

    public List<Product> getAllProducts() {
        List<Product> products = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_PRODUCTS + " ORDER BY " + COL_PRODUCT_NAME, null);
        if (cursor.moveToFirst()) {
            do {
                Product product = new Product(
                        cursor.getInt(cursor.getColumnIndexOrThrow(COL_PRODUCT_ID)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_PRODUCT_NAME)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_PRODUCT_DESCRIPTION)),
                        cursor.getDouble(cursor.getColumnIndexOrThrow(COL_PRODUCT_PRICE)),
                        cursor.getInt(cursor.getColumnIndexOrThrow(COL_PRODUCT_QUANTITY))
                );
                products.add(product);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return products;
    }

    public Product getProductById(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_PRODUCTS, null,
                COL_PRODUCT_ID + "=?", new String[]{String.valueOf(id)},
                null, null, null);
        Product product = null;
        if (cursor != null && cursor.moveToFirst()) {
            product = new Product(
                    cursor.getInt(cursor.getColumnIndexOrThrow(COL_PRODUCT_ID)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COL_PRODUCT_NAME)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COL_PRODUCT_DESCRIPTION)),
                    cursor.getDouble(cursor.getColumnIndexOrThrow(COL_PRODUCT_PRICE)),
                    cursor.getInt(cursor.getColumnIndexOrThrow(COL_PRODUCT_QUANTITY))
            );
            cursor.close();
        }
        db.close();
        return product;
    }

    public boolean updateProduct(Product product) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_PRODUCT_NAME, product.getName());
        values.put(COL_PRODUCT_DESCRIPTION, product.getDescription());
        values.put(COL_PRODUCT_PRICE, product.getPrice());
        values.put(COL_PRODUCT_QUANTITY, product.getQuantity());
        int rows = db.update(TABLE_PRODUCTS, values,
                COL_PRODUCT_ID + "=?", new String[]{String.valueOf(product.getId())});
        db.close();
        return rows > 0;
    }

    public boolean deleteProduct(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rows = db.delete(TABLE_PRODUCTS,
                COL_PRODUCT_ID + "=?", new String[]{String.valueOf(id)});
        db.close();
        return rows > 0;
    }

    public List<Product> searchProducts(String query) {
        List<Product> products = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_PRODUCTS +
                " WHERE " + COL_PRODUCT_NAME + " LIKE ? OR " + COL_PRODUCT_DESCRIPTION + " LIKE ?" +
                " ORDER BY " + COL_PRODUCT_NAME,
                new String[]{"%" + query + "%", "%" + query + "%"}
        );
        if (cursor.moveToFirst()) {
            do {
                Product product = new Product(
                        cursor.getInt(cursor.getColumnIndexOrThrow(COL_PRODUCT_ID)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_PRODUCT_NAME)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_PRODUCT_DESCRIPTION)),
                        cursor.getDouble(cursor.getColumnIndexOrThrow(COL_PRODUCT_PRICE)),
                        cursor.getInt(cursor.getColumnIndexOrThrow(COL_PRODUCT_QUANTITY))
                );
                products.add(product);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return products;
    }
}
