package com.example.crudapp.activities;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.crudapp.R;
import com.example.crudapp.database.DatabaseHelper;
import com.example.crudapp.models.Product;

public class ProductFormActivity extends AppCompatActivity {

    private EditText etName, etDescription, etPrice, etQuantity;
    private Button btnSave, btnCancel;
    private DatabaseHelper dbHelper;
    private int productId = -1;
    private boolean isEditing = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_form);

        dbHelper = new DatabaseHelper(this);

        etName = findViewById(R.id.etName);
        etDescription = findViewById(R.id.etDescription);
        etPrice = findViewById(R.id.etPrice);
        etQuantity = findViewById(R.id.etQuantity);
        btnSave = findViewById(R.id.btnSave);
        btnCancel = findViewById(R.id.btnCancel);

        // Verificar se é edição
        productId = getIntent().getIntExtra("productId", -1);
        if (productId != -1) {
            isEditing = true;
            setTitle("Editar Produto");
            loadProduct(productId);
        } else {
            setTitle("Novo Produto");
        }

        btnSave.setOnClickListener(v -> saveProduct());
        btnCancel.setOnClickListener(v -> finish());
    }

    private void loadProduct(int id) {
        Product product = dbHelper.getProductById(id);
        if (product != null) {
            etName.setText(product.getName());
            etDescription.setText(product.getDescription());
            etPrice.setText(String.valueOf(product.getPrice()));
            etQuantity.setText(String.valueOf(product.getQuantity()));
        }
    }

    private void saveProduct() {
        String name = etName.getText().toString().trim();
        String description = etDescription.getText().toString().trim();
        String priceStr = etPrice.getText().toString().trim();
        String quantityStr = etQuantity.getText().toString().trim();

        if (TextUtils.isEmpty(name)) {
            etName.setError("Informe o nome do produto");
            etName.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(priceStr)) {
            etPrice.setError("Informe o preço");
            etPrice.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(quantityStr)) {
            etQuantity.setError("Informe a quantidade");
            etQuantity.requestFocus();
            return;
        }

        double price;
        int quantity;
        try {
            price = Double.parseDouble(priceStr);
            quantity = Integer.parseInt(quantityStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Valores inválidos", Toast.LENGTH_SHORT).show();
            return;
        }

        if (price < 0) {
            etPrice.setError("Preço inválido");
            return;
        }
        if (quantity < 0) {
            etQuantity.setError("Quantidade inválida");
            return;
        }

        boolean success;
        if (isEditing) {
            Product product = new Product(productId, name, description, price, quantity);
            success = dbHelper.updateProduct(product);
            Toast.makeText(this, success ? "Produto atualizado!" : "Erro ao atualizar.", Toast.LENGTH_SHORT).show();
        } else {
            Product product = new Product(name, description, price, quantity);
            success = dbHelper.addProduct(product);
            Toast.makeText(this, success ? "Produto adicionado!" : "Erro ao adicionar.", Toast.LENGTH_SHORT).show();
        }

        if (success) finish();
    }
}
